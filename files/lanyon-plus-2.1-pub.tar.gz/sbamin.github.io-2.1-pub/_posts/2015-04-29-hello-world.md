---
layout: post
title: "Hello World!"
slug: "hello_world"
description: "Welcome to my website"
category: views
tags: 
  - welcome
  - theme
  - template
show_meta: true
comments: true
mathjax: true
videofeature: "https://www.youtube.com/watch?v=4TrOCv5Kukk"
imagefeature: "http://img.youtube.com/vi/4TrOCv5Kukk/0.jpg"
videocredit: github
published: true
date: "2015-04-29 20:00 -0600"
noindex: false
---

Welcome to my website, [example.com]({{ site.url }})

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

<!--more-->

### <i class="fa fa-bullhorn fa-2x"></i> Hello World!

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?

***

## code highlight:

{% highlight bash %}
ls
cd ~
echo "hello world"
{% endhighlight %}

***

## video:

<p></p>
<div class="ytube-video-container">
<iframe width="560" height="315" src="https://www.youtube.com/embed/4TrOCv5Kukk" frameborder="0" allowfullscreen></iframe>
</div>
<p></p>

END
