---
#NOTE: This page is required at your example.com/disclosure/ location to display original MIT license and references to third-party code snippets.
layout: page
permalink: /disclosure/
title: Disclosure
description: "This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License"
noindex: false
published: true
---

This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.

**Theme Credit:** [*lanyon*](https://github.com/poole/lanyon) by [Mark Otto](https://github.com/mdo), enhanced by [Samir B. Amin](http://sbamin.com)

#### Released under MIT License

Copyright (c) 2014 Mark Otto.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


***

<i class="fa fa-thumbs-o-up fa-2x"></i> Website made possible by open source efforts from:

*   [Jekyll](https://jekyllrb.com)
*   [Footer social icons by Lauren Clark](http://codepen.io/Deadlymuffin/pen/hGiqo/)
*   [CSS and jekyll tips from HMFAYSAL OMEGA by HMFAYSAL](https://github.com/hmfaysal/hmfaysal-omega-theme)
*   [Font Awesome Icons](http://fortawesome.github.io/Font-Awesome/icons/)
*   Tag cloud:
    *   By [Tobias Sjosten](https://github.com/tobiassjosten/tobiassjosten.github.io)
    *   By [Thibaut Courouble](https://github.com/Thibaut) at [cssflow.com](http://www.cssflow.com/snippets/sliding-tags)
*   [Responsive YouTube Playlist Embedding by John](http://avexdesigns.com/responsive-youtube-embed/)
*   [Related posts without plugin by Ross Gardler](http://rgardler.github.io/2015/07/28/adding-related-posts-to-jekyll-blog/)
*   [Archive page by Reyhan Dhuny and Michael Rowe](http://reyhan.org/2013/03/jekyll-archive-without-plugins.html)
*   [Print css by Pieter Beulque and David Walsh](http://www.webdesignerdepot.com/2010/01/10-tips-for-better-print-style-sheets/)
*   [Embed gists by Blair Vanderhoof](https://github.com/blairvanderhoof/gist-embed)



