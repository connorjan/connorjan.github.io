## Hello World!

**Theme Credit:** [*lanyon*](https://github.com/poole/lanyon) by [Mark Otto](https://github.com/mdo), enhanced by [Samir B. Amin](http://sbamin.com)

#### v2.1 features:

* prose.io detailed configuration for pages and posts
* archive page
* mature print css: clean print layout, comments on separate page, hide video and meta info, conditional print message.
* conditional gist embed css
* sitemap
* tags
*   related posts
*   twitter cards for video, images, text summary.
*   open graph features
*   footer social icons
*   sidebar menu fix
*   twitter timeline
*   twitter share missing (error 404) link
*   responsive video css
*   mathjax support

##### License

Open sourced under the [MIT license](LICENSE.md).  

END
